'use strict';

app.controller('HomeController',
        function($scope, adsService, notifyService, pageSize){
    $scope.ready = false;

    $scope.adsParams = {
        'startPage' : 1,
        'pageSize' : pageSize
    };

    $scope.reloadAds = function(){
        adsService.getAds($scope.adsParams,
        function success(data){
            $scope.data = data;
            $scope.ready = true;
        },
        function error(error){
            notifyService.showError("Cannot load ads", error);
        })
    };

    $scope.reloadAds();

    $scope.$on("categorySelectionChanged", function(event, selectedCategoryId){
        $scope.adsParams.categoryId = selectedCategoryId;
        $scope.adsParams.startPage = 1;
        $scope.reloadAds();
    });

    $scope.$on("townSelectionChanged", function(event, selectedTownId){
        $scope.adsParams.townId = selectedTownId;
        $scope.adsParams.startPage = 1;
        $scope.reloadAds();
    });

    //adsService.getAds(
    //    null,
    //    function success(data){
    //        $scope.data = data;
    //        console.log(data);
    //    },
    //    function error(err){
    //        notifyService.showError("Cannot load ads", err);
    //    }
    //);
});